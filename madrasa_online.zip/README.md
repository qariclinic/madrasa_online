# Madrasa Online

This is a ready Flutter WebView project. Replace assets/index.html with your PWA/website files,
then push to GitHub. GitHub Actions will build APK and AAB automatically.
